Due to the existing code base I had written for this project, I have elected to use Python + Pyqt, let me know if this will cause problems for you.

In order to be able to run programs:
>> pip3 install -r requirements.txt

Note, on one of the machines I tested on I had to also run:
>> sudo apt-get install python3-tk

To launch Program
>> python3 guidemo.py

Can drag to change view angle and scroll to zoom.
"Run Tests" Button will load and display data from several test images in sequence
"Wireframe"/"Solid" Button switches between displaying a solid model and displaying wireframe
